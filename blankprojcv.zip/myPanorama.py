from proj import generatePanorama
# #img 2:
# generatePanorama(r'C:\workspace\blankprojcv\data\inp\mine\im2', 'out2.jpg')

#img 1:
generatePanorama(r'C:\workspace\blankprojcv\data\inp\mine\im', 'out1.jpg')
